VeriWorkly Brand Kit
=====================

This kit contains the VeriWorkly logomark at a few common sizes, plus the
brand's color and typography reference. For the full interactive guide
(including live component examples), see:

  https://veriworkly.com/brand-kit
  https://veriworkly.com/style-guide

Logo
----
logo/veriworkly-logo-256.png          Primary square mark, 256x256
logo/veriworkly-icon-192.png          App icon, 192x192
logo/veriworkly-icon-512.png          App icon, 512x512
logo/veriworkly-icon-apple-touch.png  Apple touch icon

Usage
-----
- Keep clear space around the mark equal to at least 25% of its width.
- Do not recolor, distort, rotate, or add effects (shadows, gradients,
  outlines) to the logo.
- Do not place the logo on backgrounds that break its contrast.
- Use "VeriWorkly" as a single word, capitalized exactly like this — not
  "Veriworkly," "veriworkly," or "Veri Workly."

Color Palette
-------------
Background       #F5F4EF
Foreground       #171717
Accent (Blue)     #2563EB
Card              #FFFFFF
Muted             #5F5C54
Border            rgba(23, 23, 23, 0.12)
Destructive       #DC2626
Accent Foreground #F8FBFF

Typography
----------
Primary font (sans): Geist Sans — var(--font-geist-sans)
Monospace font:      Geist Mono — var(--font-geist-mono)
Both are bundled and exposed through the @veriworkly/ui package.

License & Source
-----------------
VeriWorkly is open-core and free-to-use. Source for these assets and the
full design system lives at:

  https://github.com/VeriWorkly/veriworkly

Questions about press or brand usage: info@veriworkly.com
